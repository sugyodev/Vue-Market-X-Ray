This is the Vue3 market application with tailwind Css.

## Project Structure

## Project setup
```
npm install
#or
yarn install
```
### Compiles and hot-reloads for development
```
npm run serve
#or
yarn serve

```
You can start on http://localhost/8080 after run above command.

And there are routes in "src/router/index.js"

### Compiles and minifies for production
```
npm run build
#or
yarn build

```
### Deployment
Deploy the "/dist" in the root directory on the server.


Hi, @alexanderlzn.
It is not comfortable to work in the fiverr chat because strict rules of platform.
If you are available, we can discuss about the project out of fiverr.
Such as skype or telegram
telegram-  vlady1030
skype-     live:.cid.8ce392ed3a3c1d20

If you don't agree, ignore it, and don't mention it on fiverr chat :)